module.exports = {
  content: ['**/*.tsx'],
  theme: {
    extend: {},
  },
  plugins: [],
}
